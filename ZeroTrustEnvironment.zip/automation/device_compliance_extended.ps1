<# 
Extended simulated device compliance scanner.

This version pretends to check:
- Domain membership
- Firewall status
- Antivirus status
- Disk encryption
- Patch currency

It only prints results and a trust decision; it does not change anything.
#>

param(
    [switch]$DomainJoined,
    [switch]$FirewallEnabled,
    [switch]$AntivirusEnabled,
    [switch]$EncryptedDisk,
    [switch]$Patched
)

$score = 0
if ($DomainJoined)     { $score += 30 }
if ($FirewallEnabled)  { $score += 20 }
if ($AntivirusEnabled) { $score += 20 }
if ($EncryptedDisk)    { $score += 15 }
if ($Patched)          { $score += 15 }

if     ($score -ge 85) { $trust = "Managed" }
elseif ($score -ge 65) { $trust = "BYOD" }
elseif ($score -ge 45) { $trust = "Guest" }
else                   { $trust = "Untrusted" }

Write-Output "Extended compliance score: $score"
Write-Output "Resulting trust level: $trust"

