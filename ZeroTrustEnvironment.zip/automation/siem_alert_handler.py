"""Simulated SIEM alert handler.

Reads sample Wazuh alerts and prints what automated actions would be taken.
"""

import json
from pathlib import Path

ALERTS_FILE = Path(__file__).resolve().parents[1] / "monitoring" / "wazuh" / "sample-alerts.json"


def handle_alert(alert):
    rid = alert["rule"]["id"]
    desc = alert["rule"]["description"]
    srcip = alert.get("srcip")
    print(f"[ALERT] {rid}: {desc}")
    if srcip:
        print(f"  - Source IP: {srcip}")
    if rid == "900100":
        print("  -> Action: Quarantine this IP and notify incident response.")
    elif rid == "900110":
        print("  -> Action: Add to watchlist, verify proxy and endpoint status.")
    else:
        print("  -> Action: Log and escalate based on severity.")


if __name__ == "__main__":
    data = json.loads(ALERTS_FILE.read_text())
    for alert in data:
        handle_alert(alert)
        print()

