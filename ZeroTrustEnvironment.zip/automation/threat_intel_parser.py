"""Simulated threat intelligence parser.

In a real environment, this would read from files or URLs.
Here it simply loads a small JSON-like structure and prints normalized IOCs.
"""

FEED = [
    {"indicator": "203.0.113.66", "type": "ip", "source": "ExampleFeed"},
    {"indicator": "malicious.example.com", "type": "domain", "source": "ExampleFeed"},
    {"indicator": "FAKEHASH123", "type": "hash", "source": "ExampleFeed"}
]

if __name__ == "__main__":
    print("Normalized IOCs from threat feed:")
    for ioc in FEED:
        print(f"- [{ioc['type']}] {ioc['indicator']} (source={ioc['source']})")

