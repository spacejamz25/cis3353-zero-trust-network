"""Simple Sysmon log parser for interesting events.

Looks for command shells, RDP-related tools, and other suspicious parent/child relationships.
"""

from pathlib import Path

LOG_FILE = Path(__file__).resolve().parents[1] / "monitoring" / "logs" / "sysmon.log"


def parse():
    print("Sysmon suspicious activity scan (simulated)")
    for line in LOG_FILE.read_text().splitlines():
        if "cmd.exe" in line or "powershell.exe" in line:
            print(f"[SUSPICIOUS] Command shell execution: {line}")
        elif "RDPClient.exe" in line:
            print(f"[NOTE] Activity from RDP client: {line}")


if __name__ == "__main__":
    parse()

