"""Simulated pfSense API quarantine script.

This does not contact a real firewall. It just prints the JSON payload that
would be sent to the pfSense API to update firewall rules for quarantine.
"""


def build_quarantine_payload(ip: str):
    return {
        "type": "rule",
        "action": "block",
        "interface": "vlan99",
        "src": ip,
        "dst": "RFC1918",
        "descr": f"Auto-quarantine for {ip} (Zero Trust policy violation)"
    }


if __name__ == "__main__":
    suspicious_ip = "10.40.10.25"
    payload = build_quarantine_payload(suspicious_ip)
    print("Would POST the following payload to pfSense API:")
    print(payload)

