# CIS 3353 – Zero Trust Network Architecture (Simulated Lab Environment)

This repository represents a **simulated but realistic** Zero Trust lab for CIS 3353.

It includes:

- pfSense-style configuration fragments
- Windows PKI template examples
- Wazuh/SIEM rule and alert samples
- Logs from "pfSense", Windows, Linux, and the SIEM (simulated)
- Automation scripts that operate on the sample data
- Lab evidence files (scan outputs, command outputs, notes)

Nothing here will reconfigure your system. These files are for **documentation,
presentation, and demonstration** of how a real environment would look.

Use this as the content behind your GitHub repo, Wiki, and presentation.

