# Demo Scenario 2 – Malicious or Unauthorized Access (Simulated)

## Story

1. Present a Guest device:
   - VLAN: 40 (Guest).
2. It tries to:
   - RDP to `192.168.20.10` (Corporate server).
   - Browse to a malicious domain in the malware category.
3. Explain:
   - Firewall blocks RDP attempt.
   - Proxy blocks malicious domain.
   - SIEM receives:
     - Firewall block event.
     - Proxy block event.
     - High‑severity "Zero Trust violation" alert.

You can use the simulated logs in:
- `documentation/testing-results/pentest-results.md`
as screenshots or copy/paste into slides.
