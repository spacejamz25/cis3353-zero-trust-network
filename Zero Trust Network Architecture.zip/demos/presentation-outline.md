# Final Presentation Outline (Zero Trust – Simulated Lab)

1. **Title & Team**
   - CIS 3353 Zero Trust Network Architecture
   - Team members

2. **Problem Statement**
   - Traditional perimeter security vs. Zero Trust
   - Why segmentation and strong identity matter

3. **High‑Level Architecture**
   - VLAN layout
   - pfSense as policy enforcement point
   - PKI as identity provider
   - Wazuh as SIEM

4. **Sprint Walkthrough**
   - Sprint 1: Network segmentation (diagram)
   - Sprint 2: PKI & certificates (explain templates)
   - Sprint 3: Access controls (trust levels, compliance score)
   - Sprint 4: Monitoring (logs, example alert JSON)
   - Sprint 5: Detection & response (behavioral + quarantine concept)
   - Sprint 6: Testing & validation (pen test + integration tests)

5. **Demo Scenarios**
   - Scenario 1: Legitimate access (allowed)
   - Scenario 2: Malicious/unauthorized access (blocked + alerted)

6. **Lessons Learned**
   - Importance of visibility and policy
   - Challenges of real deployments
   - Future work (automating more, integrating real APIs)

7. **Q&A**
