# Demo Scenario 1 – Legitimate Access (Simulated)

## Story

1. Present a "Managed" corporate laptop:
   - Compliance score: 90 (see `device-compliance.ps1`).
   - VLAN: 20 (Corporate).
2. Time is 10:00 (BusinessHours).
3. User accesses `https://internal-app.zerotrust.local`.
4. Explain:
   - Firewall allows Corp → DMZ HTTPS.
   - Proxy allows site (business category).
   - SIEM records normal access only.

You can show:
- A slide with the compliance score output.
- A fake "allowed" log entry.
