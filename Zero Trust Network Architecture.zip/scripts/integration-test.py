"""integration-test.py

Simulated end-to-end integration tests for the Zero Trust design.

Run with Python to print the scenarios and expected outcomes.
"""

def scenario_managed_device_businesshours():
    print("[IT-1] Managed device, BusinessHours, allowed app → EXPECT ALLOW")

def scenario_untrusted_device():
    print("[IT-2] Untrusted device → EXPECT QUARANTINE / BLOCK")

def scenario_guest_afterhours():
    print("[IT-3] Guest device AfterHours → EXPECT BLOCK")

def main():
    print("=== Zero Trust Integration Test Suite (Simulated) ===")
    scenario_managed_device_businesshours()
    scenario_untrusted_device()
    scenario_guest_afterhours()
    print("=== End of simulated integration tests ===")

if __name__ == "__main__":
    main()
