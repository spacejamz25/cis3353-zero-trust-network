"""auto-quarantine.py

Simulated quarantine script: given an IP, prints what actions would be taken.
"""

def quarantine_device(ip_address: str):
    print(f"[ACTION] Would add firewall rule to move/block {ip_address} in Quarantine VLAN (simulated).")

def main():
    print("=== Auto-Quarantine Stub (Simulated) ===")
    quarantine_device("192.168.40.10")

if __name__ == "__main__":
    main()
