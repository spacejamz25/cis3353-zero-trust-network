"""threat-intel-updater.py

Simulated threat intelligence updater. It just prints example indicators.
"""

def fetch_feeds():
    print("[TI] Downloaded sample threat feed (simulated).")

def parse_feeds():
    print("[TI] Parsed 3 malicious IPs and 2 domains:")
    print("     - 203.0.113.66")
    print("     - 198.51.100.23")
    print("     - 192.0.2.99")
    print("     - bad-malware.example")
    print("     - phishing-login.example")

def main():
    print("=== Threat Intel Updater (Simulated) ===")
    fetch_feeds()
    parse_feeds()

if __name__ == "__main__":
    main()
