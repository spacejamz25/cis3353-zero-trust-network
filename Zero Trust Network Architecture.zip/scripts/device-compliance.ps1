<# 
 device-compliance.ps1
 Simulated device compliance script.

 This script does NOT query a real domain or AV engine; it just
 uses variables to represent checks so you can talk through how
 it would work.

 You can run it in PowerShell to see the messages.
#>

Write-Host "Running basic device compliance checks (simulated)..."

# Simulated attributes – change these to show different scores
$domainJoined    = $true
$firewallEnabled = $true
$avRunning       = $false

$score = 100

if (-not $domainJoined)    { $score -= 40 }
if (-not $firewallEnabled) { $score -= 30 }
if (-not $avRunning)       { $score -= 30 }

Write-Host "Compliance score:" $score

if     ($score -ge 80) { Write-Host "Trust Level: Managed" }
elseif ($score -ge 60) { Write-Host "Trust Level: BYOD" }
elseif ($score -ge 40) { Write-Host "Trust Level: Guest" }
else                   { Write-Host "Trust Level: Untrusted (Quarantine)" }
