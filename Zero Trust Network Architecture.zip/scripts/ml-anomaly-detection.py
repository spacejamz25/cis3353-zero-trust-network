"""ml-anomaly-detection.py

Simulated anomaly detection. Does not use real ML libraries, but
demonstrates how you would talk about anomaly scoring.
"""

def analyze_sample_logs():
    print("[ML] Loaded 1000 log entries (simulated).")
    print("[ML] Detected 3 outliers with unusual traffic volume.")
    print("[ML] Example: src=192.168.20.15 sent 5x normal data to external IPs.")

def main():
    print("=== ML Anomaly Detection (Simulated) ===")
    analyze_sample_logs()

if __name__ == "__main__":
    main()
