"""slack-alert.py

Simulated Slack alert sender. In a real deployment this would POST
to a Slack webhook; here it prints to stdout for demo purposes.
"""

def send_alert(message: str):
    print(f"[SLACK] {message}")

def main():
    print("=== Zero Trust Alert Demo (Simulated) ===")
    send_alert("Zero Trust policy violation: Guest attempted RDP to Corporate server.")
    send_alert("High-risk login attempt detected outside BusinessHours.")

if __name__ == "__main__":
    main()
