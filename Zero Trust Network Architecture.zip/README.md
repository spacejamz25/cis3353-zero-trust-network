# 🔐 CIS 3353 Zero Trust Network Architecture Project  
### Simulated Lab Implementation with PKI, SIEM, Threat Detection & Response

This repository represents a **complete Zero Trust project** for CIS 3353, with:

- Finished sprint notes (Sprints 1–6)
- Simulated but realistic test results
- Example detection & response scripts
- Clear alignment to milestones and issues

> ⚠️ Note: This project uses **simulated lab outputs** (pfSense logs, Wazuh alerts, etc.) that are written to look like real systems.  
> It is designed for documentation, understanding, and presentation, not for live deployment.

## Structure

- `architecture/` – where you would store network & SIEM diagrams.
- `documentation/` – sprint notes, architecture write‑up, final checklist, and testing results.
- `scripts/` – example PowerShell/Python scripts that run locally and simulate behavior.
- `demos/` – scripted demo scenarios for your presentation.

See `documentation/sprint-notes/` for sprint‑by‑sprint details.
