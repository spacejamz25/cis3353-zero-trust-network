# Sprint 3 – Access Controls & Enforcement

## Goal
Tie device posture, trust level, and time of day into access decisions.

## Device Trust Levels

We defined four trust levels:

- **Managed** – Domain‑joined, patched, AV + firewall on.
- **BYOD** – Unmanaged owner device, limited access.
- **Guest** – Temporary or visitor devices, internet‑only.
- **Untrusted** – Failing checks or unknown, moved to Quarantine.

These are documented conceptually; we did not integrate with a real NAC.

## Compliance Script (device-compliance.ps1)

The script in `scripts/device-compliance.ps1` simulates:

- Checking if the device is domain‑joined (static variable for now).
- Checking firewall and AV status (simulated booleans).
- Producing a score from 0–100.

We assume this score maps as:

- 80–100 → Managed
- 60–79  → BYOD
- 40–59  → Guest
- 0–39   → Untrusted

## Time‑Based Rules

We conceptually created:

- **BusinessHours** – Mon–Fri 08:00–18:00.
- **AfterHours** – All other times.

During AfterHours, only admin access (Mgmt VLAN) is allowed to management ports.

## Proxy / Filtering Concept

We documented Squid/SquidGuard‑like behavior:

- Business sites allowed.
- Social media and streaming restricted to certain VLANs.
- Malicious categories fully blocked.

## Notes for Presentation

- Show how a high‑score device is "Managed", while a failing device is "Untrusted".
- Emphasize that access is **not just IP‑based**, but depends on posture and time.
