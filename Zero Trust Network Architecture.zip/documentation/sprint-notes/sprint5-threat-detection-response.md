# Sprint 5 – Threat Detection & Response

## Goal
Demonstrate how Zero Trust detection and response could work using simulated data.

## Behavioral / UEBA‑Style Scenarios

We describe, rather than implement:

- A user normally logging in from VLAN 20 between 08:00–17:00,
  suddenly generating failed logon attempts from VLAN 40 at 02:00.
- A device that usually only talks to internal servers suddenly sending
  large amounts of outbound traffic to unknown IPs.

These are good examples to talk through in class as "what the SIEM should flag".

## ML / Anomaly Detection Script

`scripts/ml-anomaly-detection.py` prints messages representing log analysis.  
In a real environment, it would ingest log files and detect outliers.

## Threat Intel Script

`scripts/threat-intel-updater.py` simulates:

- Downloading a threat feed.
- Parsing indicators (IPs/domains).
- Making them available for matching in a SIEM.

## Auto‑Quarantine Concept

`scripts/auto-quarantine.py` shows how, given an IP, a script might:

- Tag it as "Quarantine".
- (In real life) call pfSense API / hypervisor to isolate it.

## Notes for Presentation

- Focus on the **workflow**: detect → decide → act.
- It's okay that the scripts only simulate; explain what the "real version" would do.
