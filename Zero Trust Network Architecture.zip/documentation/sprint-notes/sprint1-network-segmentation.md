# Sprint 1 – Network Segmentation

## Goal
Design a segmented network as the foundation for Zero Trust.

## What We "Implemented" (Simulated)

- Defined five VLANs:
  - VLAN 10 – Management (192.168.10.0/24)
  - VLAN 20 – Corporate (192.168.20.0/24)
  - VLAN 30 – DMZ (192.168.30.0/24)
  - VLAN 40 – Guest (192.168.40.0/24)
  - VLAN 99 – Quarantine (192.168.99.0/24)
- Set a default deny‑all policy between VLANs.
- Allowed only:
  - Corp → DMZ on HTTPS (TCP/443).
  - Mgmt → all VLANs (for admins only).
  - Guest → Internet only via NAT.
- Conceptually placed:
  - A domain controller in VLAN 20.
  - A web server in VLAN 30.
  - A "guest laptop" in VLAN 40.

## Example (Simulated) pfSense Rule Summary

```text
PASS  VLAN20_NET  VLAN30_WEB_SERVER  TCP 443 (HTTPS)
PASS  VLAN10_MGMT VLAN_ANY           ANY (Admin mgmt)
PASS  VLAN40_GUEST ANY               TCP 80/443 (NAT to Internet)
BLOCK VLAN_ANY    VLAN_ANY           ANY (implicit deny)
```

## Notes for Presentation

- Emphasize that every segment is treated as **untrusted** by default.
- Show a diagram from `architecture/network-diagrams/` when you draw it.
