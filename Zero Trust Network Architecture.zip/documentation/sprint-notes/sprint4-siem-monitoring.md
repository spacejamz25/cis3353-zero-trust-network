# Sprint 4 – SIEM & Monitoring

## Goal
Add centralized visibility with a SIEM (Wazuh‑style).

## Simulated Log Sources

We assume the following logs are forwarded:

- pfSense firewall logs (allow/deny events).
- Windows Security + Sysmon logs (process creation, logon events).
- Linux auth and system logs.

## Example (Simulated) pfSense Log Line

```text
<134>filterlog: 3,,1000000103,em0,match,block,in,4,0x0,,64,12345,0,DF,6,tcp,60,192.168.40.10,192.168.20.10,51514,3389,RA
```

This represents a Guest VLAN client trying to RDP into a Corporate server (blocked).

## Example (Simulated) Wazuh Alert

```json
{
  "rule": {
    "id": "900101",
    "level": 10,
    "description": "Zero Trust policy violation: Guest VLAN attempted access to Corporate RDP"
  },
  "agent": {
    "name": "wazuh-pfsense-collector"
  },
  "srcip": "192.168.40.10",
  "dstip": "192.168.20.10",
  "location": "pf: /var/log/filter.log"
}
```

## Dashboards (Concept)

We describe a "Zero Trust Overview" dashboard:

- Panel 1 – Firewall blocks by source VLAN.
- Panel 2 – Top 10 policy violations.
- Panel 3 – Authentication failures over time.
- Panel 4 – High‑severity alerts.

## Notes for Presentation

- You can screenshot the JSON and log lines directly from this repo as "example alerts".
- Explain what each alert would mean operationally.
