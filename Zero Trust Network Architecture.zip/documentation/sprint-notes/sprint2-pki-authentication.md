# Sprint 2 – PKI & Authentication

## Goal
Bring identity and certificates into the Zero Trust design.

## Simulated Implementation

- Defined an AD forest: `zerotrust.local`.
- Created a Root CA and an Enterprise CA (conceptually).
- Planned certificate templates:
  - `ZT_User_Auth` – User authentication (Client Auth EKU).
  - `ZT_Computer_Auth` – Computer authentication.
  - `ZT_VPN_Client` – For VPN/EAP‑TLS style usage.
- Auto‑enrollment concept:
  - Domain‑joined machines automatically receive `ZT_Computer_Auth`.
  - Domain users receive `ZT_User_Auth` at first logon.
- Explained CRL & OCSP concept:
  - Certificates can be revoked when a device leaves the org or is compromised.

## Example Certificate Use‑Case (Simulated)

- A "Corporate Laptop" in VLAN 20 has:
  - AD computer account.
  - Auto‑enrolled computer certificate.
- When this laptop requests access to a sensitive web app:
  - The reverse proxy (conceptually) validates the client certificate.
  - Access is only granted if the certificate is valid and not revoked.

## Notes for Presentation

- Treat PKI as the "identity backbone" of Zero Trust.
- You can show a certificate screenshot later if you build a small lab.
