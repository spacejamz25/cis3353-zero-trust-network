# Final Project Checklist (Simulated Completion)

Use this to verify you have documentation for each major area.

## Sprint 1 – Network Segmentation
- [x] Segmentation design documented
- [x] VLAN plan defined (Mgmt, Corp, DMZ, Guest, Quarantine)
- [x] Example pfSense rule set described
- [x] Network diagram placeholder defined

## Sprint 2 – PKI & Authentication
- [x] PKI architecture described
- [x] Certificate templates listed
- [x] Auto‑enrollment concept explained
- [x] Example certificate usage documented

## Sprint 3 – Access Controls & Enforcement
- [x] Device trust levels defined
- [x] Compliance score logic explained
- [x] Mapping score → trust → policy described
- [x] Time‑based rules and proxy filtering documented

## Sprint 4 – SIEM & Monitoring
- [x] Wazuh components described
- [x] Log sources listed (pfSense, endpoints)
- [x] Example detection rules shown
- [x] Dashboard concept explained

## Sprint 5 – Threat Detection & Response
- [x] Behavioral detection scenarios written
- [x] Anomaly detection concept demonstrated in script
- [x] Threat intelligence ingestion simulated
- [x] Quarantine + alert workflow described

## Sprint 6 – Testing & Final Presentation
- [x] Penetration test scenarios documented
- [x] Integration test matrix created
- [x] Demo scenarios scripted
- [x] Presentation outline prepared
