# Integration Test Results (Simulated)

These tests validate that the different Zero Trust components work together conceptually.

---

## Test IT‑1 – Compliant Device, BusinessHours, Allowed Resource

**Scenario:**  
Managed corporate laptop with valid certificate during BusinessHours accessing internal web app.

**Assumptions:**
- Device has compliance score 90 (Managed).
- Time is 10:00 (BusinessHours).
- Destination is a permitted internal HTTPS service.

**Expected Behavior:**
- Firewall allows traffic.
- Proxy allows site (business category).
- SIEM logs access but does not raise a high‑severity alert.

**Result:** ✅ PASS (as described)

---

## Test IT‑2 – Non‑Compliant Device, BusinessHours, Corporate Resource

**Scenario:**  
Device with low compliance score (e.g., missing AV/firewall).

**Assumptions:**
- `device-compliance.ps1` returns a score of 35 (Untrusted).
- Policy maps Untrusted → Quarantine VLAN.

**Expected Behavior:**
- Device is "placed" into Quarantine (conceptually).
- Cannot reach Corporate or DMZ addresses.
- SIEM logs repeated blocks, possible medium‑level alert.

**Result:** ✅ PASS (simulated quarantine behavior)

---

## Test IT‑3 – Guest Device, AfterHours, Sensitive Resource

**Scenario:**  
Guest tries to reach a DMZ server after hours.

**Expected Behavior:**
- Blocked by both VLAN rules and time policy.
- SIEM logs a Zero Trust policy violation.

**Result:** ✅ PASS (simulated behavior)

---

Use these integration tests as talking points in your presentation to show how identity, network, policy, and monitoring all tie together.
