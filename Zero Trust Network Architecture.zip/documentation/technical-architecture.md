# Technical Architecture – CIS 3353 Zero Trust Network (Simulated Lab)

This document describes the **final state** of the simulated Zero Trust lab.

## 1. Network Segmentation (Sprint 1)

We designed a segmented network using pfSense (conceptual):

- VLAN 10 – Management
- VLAN 20 – Corporate
- VLAN 30 – DMZ / Servers
- VLAN 40 – Guest / BYOD
- VLAN 99 – Quarantine

All inter‑VLAN traffic defaults to **deny**, with explicit allows for:
- Corporate → DMZ HTTPS
- Management → All (admin‑only)
- Guest → Internet only (NAT)

Sample (simulated) pfSense rule set is described in the Sprint 1 notes.

## 2. Identity & PKI (Sprint 2)

We modeled a Windows AD + AD CS environment:

- Root CA and Enterprise Subordinate CA (conceptual).
- Templates:
  - `User_Auth_Template`
  - `Computer_Auth_Template`
  - `VPN_Client_Auth`
- Auto‑enrollment via Group Policy for lab‑joined devices.

The documentation assumes EAP‑TLS style access (even if not physically wired up in a lab).

## 3. Access Control & Policy Enforcement (Sprint 3)

The Zero Trust decision logic is based on:

- **Device Trust Level** (Managed, BYOD, Guest, Untrusted).
- **Compliance Score** (0–100) from `scripts/device-compliance.ps1`.
- **Time of Day** (BusinessHours / AfterHours schedules).
- **Resource Sensitivity** (Corporate vs Guest vs DMZ).

Firewall, proxy and schedule concepts are all described as if they were implemented in pfSense and Squid/SquidGuard, with rule examples in the sprint notes.

## 4. Monitoring & SIEM (Sprint 4)

We use Wazuh conceptually as the SIEM:

- pfSense → Wazuh via syslog.
- Windows endpoint → Wazuh agent + Sysmon.
- Linux server → Wazuh agent.

The simulated alerts in `documentation/testing-results/` mimic:
- Firewall blocks,
- Authentication failures,
- Policy violations.

## 5. Threat Detection & Response (Sprint 5)

Detection and response are documented as:

- Behavioral / UEBA‑style rules (described in prose).
- ML‑style anomaly detection via `scripts/ml-anomaly-detection.py` (simulated analysis).
- Threat intelligence ingestion via `scripts/threat-intel-updater.py` (parsing sample feeds).
- Auto‑quarantine concept via `scripts/auto-quarantine.py`.

## 6. Testing & Final Presentation (Sprint 6)

Penetration tests, integration tests, and demo scenarios are fully written up as simulations:

- `documentation/testing-results/pentest-results.md`
- `documentation/testing-results/integration-tests.md`
- `demos/` folder for presentation talking points.

This makes the project **presentation‑ready**, even if the full lab is not yet physically deployed.
