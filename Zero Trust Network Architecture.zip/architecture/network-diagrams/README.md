# Network Diagrams (Placeholders)

In a real deployment, you would export diagrams here, such as:

- `logical-topology.png`
- `vlan-layout.png`
- `zerotrust-siem-view.png`

For the purposes of this simulated project, you can:
- Sketch these by hand and export as PNG, **or**
- Build them in draw.io / PowerPoint and save here.

Reference these images from:
- `documentation/technical-architecture.md`
- `demos/presentation-outline.md`
