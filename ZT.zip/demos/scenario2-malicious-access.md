# Demo Scenario 2 – Malicious / Policy-Violating Access

- Device: Guest/BYOD client
- Action: Attempt RDP to internal server and browse to malicious domain.
- Expected:
  - Firewall: block RDP attempt.
  - Proxy: block malicious domain.
  - SIEM: create high-severity Zero Trust policy violation alerts.
