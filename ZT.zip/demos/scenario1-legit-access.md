# Demo Scenario 1 – Legitimate Access

- User: Alice (Managed workstation, Corporate VLAN)
- Action: Access internal web app during business hours.
- Expected:
  - Firewall: allow Corp -> DMZ HTTPS.
  - SIEM: logs connection, no critical alerts.
