# Sprint 2 – PKI & Authentication

> NOTE: This sprint log is written for a simulated lab. It documents the *design* and *expected behavior*,
> not the output of a physical deployment.

## Goals

- High-level goal(s) for this sprint.
- Link to the corresponding GitHub milestone and user story.

## Work Completed

- Designed and documented the components for this sprint.
- Updated issues on the GitHub board to reflect progress.
- Captured decisions and assumptions for a future real lab build.

## Notes

Use this file to expand with more detailed notes if you walk through commands or screenshots during your presentation.
