# Integration Tests (Simulated)

These tests verify that the **design** is internally consistent.

## IT-01: Compliant Managed Device

- Trust level: Managed
- VLAN: Corporate
- Expected:
  - Access to approved internal resources.
  - No high-severity alerts in SIEM.
  - Normal authentication logs only.

## IT-02: Non-Compliant Device

- Trust level: Untrusted
- VLAN: Quarantine
- Expected:
  - No access to internal subnets.
  - DNS/HTTP allowed only to remediation resources or update servers.
  - Multiple firewall denies recorded.

## IT-03: Guest Attempting Privileged Access

- Trust level: Guest
- Expected:
  - Attempts to reach management/DMZ networks are blocked.
  - SIEM records a Zero Trust policy violation event.
