"""Simulated Slack alert sender.

In a real environment this would use a webhook. Here it just prints the message.
"""

def send_alert(text):
    print(f"[SLACK] {text}")

if __name__ == "__main__":
    send_alert("Zero Trust Alert: Guest device attempted RDP to corporate server. Investigation required.")
