"""Simulated anomaly detection script.

Reads a small in-memory list of log-like events and prints which ones would be
considered 'interesting' from a Zero Trust perspective.
"""

events = [
    {"src": "10.20.10.15", "dst": "10.30.10.10", "action": "allow", "note": "normal web access"},
    {"src": "10.40.10.25", "dst": "10.20.10.10", "action": "block", "note": "guest RDP attempt"},
    {"src": "10.20.10.16", "dst": "198.51.100.5", "action": "block", "note": "malicious domain via proxy"},
]

if __name__ == "__main__":
    print("ML/Anomaly Detection (Simulated)")
    for ev in events:
        if ev["action"] == "block":
            print(f"[ALERT] Suspicious/blocked event: {ev}")
