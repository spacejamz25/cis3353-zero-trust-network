"""Simulated threat intelligence updater.

In a real environment this would pull feeds from external sources.
Here it simply prints a few example indicators.
"""

indicators = [
    {"type": "domain", "value": "malicious.example.com"},
    {"type": "ip", "value": "203.0.113.66"},
    {"type": "hash", "value": "FAKEHASH123"},
]

if __name__ == "__main__":
    print("Threat Intelligence Feed (Simulated)")
    for ioc in indicators:
        print(f"- {ioc['type']}: {ioc['value']}")
