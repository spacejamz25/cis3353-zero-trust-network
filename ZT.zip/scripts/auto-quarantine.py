"""Simulated auto-quarantine workflow.

This does not touch any real firewall. It just shows the kind of change
that would be made when a device is quarantined.
"""

def quarantine(ip):
    print(f"[ACTION] Would move {ip} into Quarantine VLAN and block internal access.")

if __name__ == "__main__":
    suspicious_ip = "10.40.10.25"
    print("Auto-Quarantine Demo")
    quarantine(suspicious_ip)
