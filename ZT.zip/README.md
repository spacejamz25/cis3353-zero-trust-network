# CIS 3353 Zero Trust Network Architecture Project

This repository contains supporting files for a **simulated** Zero Trust Network Architecture (ZTNA) lab.
These files are designed for documentation and demonstration purposes for the CIS 3353 course.

- The network and policies are based on pfSense, Windows, and Wazuh concepts.
- Scripts are lightweight and safe: they only print simulated behavior, they do **not** modify the system.
- Test results are written as if the design had been implemented in a full lab.

For full context, see the GitHub Wiki and sprint notes.
